﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PaymentDetails.Configuration;

namespace PaymentDetails.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {
    }
}
